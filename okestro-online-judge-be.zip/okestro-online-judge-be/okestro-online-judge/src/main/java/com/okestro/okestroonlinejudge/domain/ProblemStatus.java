package com.okestro.okestroonlinejudge.domain;

/**
 * 문제 풀이 상태 열거형.
 *
 * @author Assistant
 * @since 1.0
 */
public enum ProblemStatus {
    SOLVED,
    ATTEMPTED,
    NOT_ATTEMPTED
}


