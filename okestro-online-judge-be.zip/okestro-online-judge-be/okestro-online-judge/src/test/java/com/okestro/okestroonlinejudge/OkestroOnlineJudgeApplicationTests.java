package com.okestro.okestroonlinejudge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OkestroOnlineJudgeApplicationTests {

    @Test
    void contextLoads() {
    }

}
